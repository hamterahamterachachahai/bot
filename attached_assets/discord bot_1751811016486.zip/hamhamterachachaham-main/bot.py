import discord
from discord.ext import commands
import asyncio
import os
from dotenv import load_dotenv
from discord import app_commands

# Load environment variables from .env file
load_dotenv()

# --- CONFIGURATION ---
TOKEN = os.getenv("DISCORD_BOT_TOKEN")
ALLOWED_USER_IDS = [int(user_id) for user_id in os.getenv("ALLOWED_USER_IDS", "").split(',') if user_id]
DELAY = float(os.getenv("DM_DELAY", 1.5))
LOG_DMS = os.getenv("LOG_DMS", "True").lower() == "true"
ALLOWED_ROLE_IDS = {int(role_id) for role_id in os.getenv("ALLOWED_ROLE_IDS", "").split(',') if role_id}
# ---------------------

# Check if the bot token is set
if not TOKEN:
    print("ERROR: DISCORD_BOT_TOKEN environment variable not found in .env file.")
    exit()

# Configure Discord Intents
intents = discord.Intents.default()
intents.members = True
intents.message_content = True

# Initialize the bot
bot = commands.Bot(command_prefix="!", intents=intents)

async def send_dm_to_members(ctx, members_to_dm, message, delay, log_dms):
    """Helper function to send DMs to a list of members."""
    total_members = len(members_to_dm)
    if total_members == 0:
        await ctx.send("No eligible members found for DM.", ephemeral=True)
        return

    await ctx.send(
        f"Attempting to DM {total_members} members. This may take a while due to delays.",
        ephemeral=True
    )
    sent_count = 0
    skipped_count = 0
    failed_count = 0

    for member in members_to_dm:
        if member == bot.user:
            if log_dms:
                print(f"Skipping self: {member.name}")
            skipped_count += 1
            continue
        if member.bot:
            if log_dms:
                print(f"Skipping bot: {member.name}")
            skipped_count += 1
            continue

        try:
            await member.send(message)
            if log_dms:
                print(f"Successfully sent DM to {member.name} ({member.id})")
            sent_count += 1
        except discord.errors.Forbidden:
            if log_dms:
                print(
                    f"Failed to send DM to {member.name} ({member.id}): DMs are closed or blocked.")
            failed_count += 1
        except Exception as e:
            if log_dms:
                print(
                    f"An unexpected error occurred sending DM to {member.name} ({member.id}): {e}")
            failed_count += 1
        finally:
            # Always sleep to respect rate limits, even on failure
            await asyncio.sleep(delay)

    await ctx.send(
        f"DM operation complete!\n"
        f"Sent: {sent_count}\n"
        f"Skipped (self/bots): {skipped_count}\n"
        f"Failed (DMs off/error): {failed_count}\n"
        f"Total attempted: {total_members}",
        ephemeral=True
    )
    print(f"DM operation finished for guild {ctx.guild.name}.")

# --- CHECK FUNCTIONS (Now slightly adjusted) ---
async def check_allowed_users(user_id, allowed_user_ids) -> bool:
    """Checks if the user's ID is in the ALLOWED_USER_IDS list."""
    return user_id in allowed_user_ids

async def check_allowed_roles(user, allowed_role_ids) -> bool:
    """Checks if the user has any of the allowed role IDs."""
    if user.guild:  # Ensure we are in a guild (server)
        member = user.guild.get_member(user.id)
        if member:
            return any(role.id in allowed_role_ids for role in member.roles)
    return False

# --- NEW COMBINED CHECK: User OR Role is allowed ---
async def check_user_or_role_allowed(user, allowed_user_ids, allowed_role_ids) -> bool:
    """
    Checks if the user is in ALLOWED_USER_IDS OR has any of the ALLOWED_ROLE_IDS.
    This function will be used for commands where only one of these conditions is required.
    """
    is_user_allowed = await check_allowed_users(user.id, allowed_user_ids)
    is_role_allowed = await check_allowed_roles(user, allowed_role_ids)
    return is_user_allowed or is_role_allowed
# -----------------------------------------------

# --- Slash Command: DM members of specific roles ---
@bot.tree.command(
    name="dmall_roles",
    description="Sends a direct message to all members of specified roles."
)
# Removed the app_commands.checks here. We'll do the check inside the command.
async def dmall_roles_command(
    interaction: discord.Interaction,
    message: str,
    target_role: discord.Role
):
    """
    Slash command to send a DM to members of a specific role.
    Usage: /dmall_roles message:<your message> target_role:<@role>
    """
    await interaction.response.defer(ephemeral=True)  # Acknowledge the command immediately

    # --- DO THE CHECK HERE ---
    if not await check_user_or_role_allowed(interaction.user, bot.allowed_user_ids, bot.allowed_role_ids):
        await interaction.followup.send("You are not authorized to use this command.", ephemeral=True)
        return
    # ------------------------

    if not interaction.guild:
        await interaction.followup.send("This command can only be used in a server.",
                                    ephemeral=True)
        return

    members_to_dm = [member for member in target_role.members]

    await send_dm_to_members(interaction.followup, members_to_dm, message, DELAY,
                            LOG_DMS)

# --- Slash Command: DM all server members ---
@bot.tree.command(
    name="dmall_server",
    description="Sends a direct message to ALL members of the server (use with caution!)."
)
# Removed the app_commands.checks here. We'll do the check inside the command.
async def dmall_server_command(
    interaction: discord.Interaction,
    message: str
):
    """
    Slash command to send a DM to all members in the server.
    Usage: /dmall_server message:<your message>
    """
    await interaction.response.defer(ephemeral=True)  # Acknowledge the command immediately

    # --- DO THE CHECK HERE ---
    if not await check_user_or_role_allowed(interaction.user, bot.allowed_user_ids, bot.allowed_role_ids):
        await interaction.followup.send("You are not authorized to use this command.", ephemeral=True)
        return
    # ------------------------

    if not interaction.guild:
        await interaction.followup.send("This command can only be used in a server.",
                                    ephemeral=True)
        return

    # Get all members in the guild (excluding bots and self is handled in send_dm_to_members)
    members_to_dm = [member for member in interaction.guild.members]

    await send_dm_to_members(interaction.followup, members_to_dm, message, DELAY,
                            LOG_DMS)

# --- Slash Command: DM a specific user ---
@bot.tree.command(
    name="dmuser",
    description="Sends a direct message to a specific user."
)
# Removed the app_commands.checks here. We'll do the check inside the command.
async def dmuser_command(
    interaction: discord.Interaction,
    target_user: discord.Member,
    message: str
):
    """
    Slash command to send a DM to a specific user.
    Usage: /dmuser target_user:<@user> message:<your message>
    """
    await interaction.response.defer(ephemeral=True)  # Acknowledge

    # --- DO THE CHECK HERE ---
    if not await check_user_or_role_allowed(interaction.user, bot.allowed_user_ids, bot.allowed_role_ids):
        await interaction.followup.send("You are not authorized to use this command.", ephemeral=True)
        return
    # ------------------------

    try:
        await target_user.send(message)
        await interaction.followup.send(
            f"Successfully sent DM to {target_user.name}.", ephemeral=True)
        if LOG_DMS:
            print(f"Successfully sent DM to {target_user.name} ({target_user.id})")
    except discord.errors.Forbidden:
        await interaction.followup.send(
            f"Failed to send DM to {target_user.name}. Their DMs might be closed or they might have blocked the bot.",
            ephemeral=True)
        if LOG_DMS:
            print(
                f"Failed to send DM to {target_user.name} ({target_user.id}): DMs are closed or blocked.")
    except Exception as e:
        await interaction.followup.send(
            f"An unexpected error occurred while sending DM to {target_user.name}: {e}",
            ephemeral=True)
        if LOG_DMS:
            print(
                f"An unexpected error occurred sending DM to {target_user.name} ({target_user.id}): {e}")

# --- Cog Loading ---
async def load_extensions():
    for filename in os.listdir('./cogs'):  # Assuming 'cogs' directory is in the same folder
        if filename.endswith('.py') and filename != 'music.py' and filename != 'economy.py':  # Exclude economy.py
            try:
                await bot.load_extension(f'cogs.{filename[:-3]}')  # Load the cog
                print(f"Loaded cog: {filename[:-3]}")
            except Exception as e:
                print(f"Failed to load cog {filename[:-3]}. Error: {e}")

@bot.event
async def on_ready():
    """Called when the bot is ready and connected to Discord."""
    print(f"Logged in as {bot.user.name} (ID: {bot.user.id})")
    print(f"Bot is in {len(bot.guilds)} guild(s).")

    # --- STORE THE IDS AND CHECK FUNCTIONS ON THE BOT INSTANCE ---
    bot.allowed_user_ids = ALLOWED_USER_IDS
    bot.allowed_role_ids = ALLOWED_ROLE_IDS
    bot.check_allowed_users = check_allowed_users
    bot.check_allowed_roles = check_allowed_roles
    bot.check_user_or_role_allowed = check_user_or_role_allowed
    # -----------------------------------------------------------

    await load_extensions()  # Load cogs when the bot is ready

    # Sync slash commands with Discord
    try:
        synced = await bot.tree.sync()
        print(f"Synced {len(synced)} global command(s).")
    except Exception as e:
        print(f"Error syncing commands: {e}")

@bot.event
async def on_command_error(ctx, error):
    """Global error handler for commands."""
    if isinstance(error, commands.MissingPermissions):
        await ctx.send(
            "You don't have the necessary permissions to run this command.",
            ephemeral=True)
    elif isinstance(error, commands.MissingRequiredArgument):
        await ctx.send(
            f"Missing argument: {error.param.name}. Please provide all required arguments.",
            ephemeral=True)
    else:
        print(f"An unhandled error occurred: {error}")
        await ctx.send("An unexpected error occurred while processing your command.",
                        ephemeral=True)

# --- Global Slash Command Error Handler ---
@bot.tree.error
async def on_app_command_error(interaction: discord.Interaction, error: app_commands.AppCommandError):
    if isinstance(error, app_commands.CheckFailure):
        await interaction.response.send_message("You are not authorized to use this command.", ephemeral=True)
    else:
        print(f"An error occurred with a slash command: {error}")
        # Optionally send a more generic error message to the user
        await interaction.response.send_message("An error occurred while processing this command.", ephemeral=True)

# --- Run the bot ---
if __name__ == "__main__":
    # The bot token should be set in the .env file as DISCORD_BOT_TOKEN
    bot.run(TOKEN)