# cogs/admin.py
import discord
from discord.ext import commands
from discord import app_commands
import os
import sys
from discord.utils import MISSING

# Declare global variables for the checks, which will be assigned in cog_load
# This is necessary because these functions are defined in bot.py's global scope.
_check_allowed_users = None
_check_allowed_roles = None
_check_user_or_role_allowed = None  # Assuming you want to use the combined check from bot.py


class Admin(commands.Cog):
    """
    Commands for bot administration (owner-only or specific roles).
    """

    def __init__(self, bot):
        self.bot = bot

    async def cog_load(self):
        """
        Assigns the global check functions from the bot instance to local variables
        when the cog is loaded. This makes them accessible within the cog's commands.
        """
        global _check_allowed_users
        global _check_allowed_roles
        global _check_user_or_role_allowed
        # Access the functions assumed to be attached to the bot instance from bot.py
        _check_allowed_users = self.bot.check_allowed_users
        _check_allowed_roles = self.bot.check_allowed_roles
        _check_user_or_role_allowed = self.bot.check_user_or_role_allowed

    async def cog_check(self, interaction: discord.Interaction) -> bool:
        """
        Global check for the Admin cog.
        Only the bot owner or users with allowed roles can use these commands.
        """
        if await self.bot.is_owner(interaction.user):
            return True
        # Use the combined check here so admin commands also follow the OR logic
        return await _check_user_or_role_allowed(interaction.user, self.bot.allowed_user_ids, self.bot.allowed_role_ids)

    # Command: Load Cog
    @app_commands.command(
        name='load_cog',
        description='Loads a specified cog.'
    )
    @commands.is_owner()  # Still keep owner-only for this critical command
    async def load_cog(self, interaction: discord.Interaction, cog_name: str):
        """Loads a specified cog."""
        await interaction.response.defer(ephemeral=True)  # Acknowledge the command immediately

        try:
            await self.bot.load_extension(f'cogs.{cog_name}')
            await interaction.followup.send(f'Successfully loaded cog: `{cog_name}`', ephemeral=True)
        except commands.ExtensionAlreadyLoaded:
            await interaction.followup.send(f'Cog `{cog_name}` is already loaded.', ephemeral=True)
        except commands.ExtensionNotFound:
            await interaction.followup.send(
                f'Cog `{cog_name}` not found. Ensure it\'s in the cogs folder and spelled correctly.', ephemeral=True)
        except Exception as e:
            await interaction.followup.send(f'Failed to load cog `{cog_name}`: {e}', ephemeral=True)

    # Command: Unload Cog
    @app_commands.command(
        name='unload_cog',
        description='Unloads a specified cog.'
    )
    @commands.is_owner()  # Still keep owner-only for this critical command
    async def unload_cog(self, interaction: discord.Interaction, cog_name: str):
        """Unloads a specified cog."""
        await interaction.response.defer(ephemeral=True)  # Acknowledge the command immediately

        if cog_name == 'admin':  # Prevent unloading the admin cog itself
            await interaction.followup.send("Cannot unload the admin cog.", ephemeral=True)
            return
        try:
            await self.bot.unload_extension(f'cogs.{cog_name}')
            await interaction.followup.send(f'Successfully unloaded cog: `{cog_name}`', ephemeral=True)
        except commands.ExtensionNotLoaded:
            await interaction.followup.send(f'Cog `{cog_name}` is not loaded.', ephemeral=True)
        except commands.ExtensionNotFound:
            await interaction.followup.send(f'Cog `{cog_name}` not found.', ephemeral=True)
        except Exception as e:
            await interaction.followup.send(f'Failed to unload cog `{cog_name}`: {e}', ephemeral=True)

    # Command: Reload Cog
    @app_commands.command(
        name='reload_cog',
        description='Reloads a specified cog.'
    )
    @commands.is_owner()  # Still keep owner-only for this critical command
    async def reload_cog(self, interaction: discord.Interaction, cog_name: str):
        """Reloads a specified cog."""
        await interaction.response.defer(ephemeral=True)  # Acknowledge the command immediately

        try:
            await self.bot.reload_extension(f'cogs.{cog_name}')
            await interaction.followup.send(f'Successfully reloaded cog: `{cog_name}`', ephemeral=True)
        except commands.ExtensionNotLoaded:
            await interaction.followup.send(f'Cog `{cog_name}` is not loaded. Attempting to load it instead.',
                                        ephemeral=True)
            try:
                await self.bot.load_extension(f'cogs.{cog_name}')
                await interaction.followup.send(f'Successfully loaded cog: `{cog_name}`', ephemeral=True)
            except Exception as e:
                await interaction.followup.send(f'Failed to load cog `{cog_name}`: {e}', ephemeral=True)
        except commands.ExtensionNotFound:
            await interaction.followup.send(f'Cog `{cog_name}` not found.', ephemeral=True)
        except Exception as e:
            await interaction.followup.send(f'Failed to reload cog `{cog_name}`: {e}', ephemeral=True)

    # Command: Shutdown (renamed to avoid conflict)
    @app_commands.command(
        name='shutdown',
        description='Shuts down the bot.'
    )
    @commands.is_owner()  # Keep owner-only for this critical command
    async def shutdown_bot(self, interaction: discord.Interaction):
        """Shuts down the bot."""
        await interaction.response.send_message("Shutting down...", ephemeral=True)
        await self.bot.close()

    # Command: Set Status
    @app_commands.command(
        name='set_status',
        description='Sets the bot\'s activity status.'
    )
    @app_commands.choices(
        activity_type=[
            discord.app_commands.Choice(name='Playing', value='playing'),
            discord.app_commands.Choice(name='Listening', value='listening'),
            discord.app_commands.Choice(name='Watching', value='watching'),
            discord.app_commands.Choice(name='Streaming', value='streaming'),
        ]
    )
    # Applying the combined check to set_status as well
    @app_commands.checks.check(lambda i: _check_user_or_role_allowed(i.user, i.client.allowed_user_ids, i.client.allowed_role_ids))
    async def set_status(self, interaction: discord.Interaction, activity_type: str, message: str):
        """Sets the bot's activity status."""
        activity = None

        if activity_type == 'playing':
            activity = discord.Game(name=message)
        elif activity_type == 'listening':
            activity = discord.Activity(type=discord.ActivityType.listening, name=message)
        elif activity_type == 'watching':
            activity = discord.Activity(type=discord.ActivityType.watching, name=message)
        elif activity_type == 'streaming':
            # For streaming, you need a Twitch URL. This is a simplified example.
            activity = discord.Activity(type=discord.ActivityType.streaming, name=message,
                                        url="https://www.twitch.tv/discord")
        else:
            # This 'else' block might not be strictly necessary with @choices, but good for robustness
            await interaction.response.send_message(
                "Invalid activity type. Choose from `playing`, `listening`, `watching`, `streaming`.",
                ephemeral=True)
            return

        await self.bot.change_presence(activity=activity)
        await interaction.response.send_message(f"Bot status set to: {activity_type.capitalize()} {message}",
                                            ephemeral=True)

    # Command: Set Owner
    @app_commands.command(
        name='set_owner',
        description='Sets the bot owner ID (for development).'
    )
    @commands.is_owner()  # Keep owner-only for this sensitive command
    async def set_owner(self, interaction: discord.Interaction, user_id: str):  # user_id as string for flexibility
        """Sets the bot owner ID."""
        try:
            self.bot.owner_id = int(user_id)
            await interaction.response.send_message(f"Bot owner ID set to: {user_id}", ephemeral=True)
        except ValueError:
            await interaction.response.send_message("Invalid user ID. Please provide a numerical ID.", ephemeral=True)

    # Command: Sync (for syncing slash commands)
    @app_commands.command(
        name='sync_commands',
        description='Syncs slash commands globally.'
    )
    @commands.is_owner()  # Keep owner-only for this powerful command
    async def sync_commands(self, interaction: discord.Interaction):
        """Syncs slash commands globally."""
        await interaction.response.defer(ephemeral=True)  # Acknowledge the command immediately
        try:
            synced = await self.bot.tree.sync()
            await interaction.followup.send(f"Synced {len(synced)} application commands globally.", ephemeral=True)
        except Exception as e:
            await interaction.followup.send(f"Error syncing commands: {e}", ephemeral=True)


async def setup(bot):
    """
    Adds the Admin cog to the bot.
    """
    await bot.add_cog(Admin(bot))