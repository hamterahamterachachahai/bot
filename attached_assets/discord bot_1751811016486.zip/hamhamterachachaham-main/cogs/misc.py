import discord
from discord.ext import commands
from discord import app_commands  # Import app_commands
import random
import aiohttp
import asyncio


class Misc(commands.Cog):
    """
    Miscellaneous commands.
    """

    def __init__(self, bot):
        self.bot = bot
        self._check_allowed_users = None
        self._check_user_or_role_allowed = None

    async def cog_load(self):
        """
        Assigns the global check functions from the bot instance to local variables
        when the cog is loaded. This makes them accessible within the cog's commands.
        """
        self._check_allowed_users = self.bot.check_allowed_users
        self._check_user_or_role_allowed = self.bot.check_user_or_role_allowed

    # Command: Urban Dictionary (uses external API)
    @app_commands.command(name='urban', description='Searches Urban Dictionary for a term.')
    async def urban(self, interaction: discord.Interaction, term: str):
        """Searches Urban Dictionary for a term."""
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(f'http://api.urbandictionary.com/v0/define?term={term}') as response:
                    if response.status == 200:
                        data = await response.json()
                        if data['list']:
                            definition = data['list'][0]['definition']
                            example = data['list'][0]['example']
                            embed = discord.Embed(
                                title=f"Urban Dictionary: {term}",
                                description=definition,
                                color=discord.Color.dark_purple(),
                            )
                            if example:
                                embed.add_field(name="Example", value=example, inline=False)
                            embed.set_footer(text="Powered by Urban Dictionary")
                            await interaction.response.send_message(embed=embed)
                        else:
                            await interaction.response.send_message(f"No definition found for '{term}'.")
                    else:
                        await interaction.response.send_message("Could not connect to Urban Dictionary API.")
        except aiohttp.ClientError:
            await interaction.response.send_message("Failed to connect to the Urban Dictionary API. Please try again later.")
        except Exception as e:
            await interaction.response.send_message(f"An unexpected error occurred: {e}")

    # Command: Google Search (placeholder for web search)
    @app_commands.command(name='google', description='Performs a Google search (placeholder).')
    async def google(self, interaction: discord.Interaction, query: str):
        """Performs a Google search (placeholder)."""
        await interaction.response.send_message(f"Searching Google for: `{query}` (This command is a placeholder)")
        await interaction.response.send_message(f"You can try: https://www.google.com/search?q={query.replace(' ', '+')}")

    # Command: Weather (placeholder for weather API)
    @app_commands.command(name='weather', description='Gets weather information for a city (placeholder).')
    async def weather(self, interaction: discord.Interaction, city: str):
        """Gets weather information for a city (placeholder)."""
        await interaction.response.send_message(f"Fetching weather for {city}... (This command is a placeholder)")
        await interaction.response.send_message("You would typically integrate with an API like OpenWeatherMap here.")

    # Command: Define (placeholder for dictionary API)
    @app_commands.command(name='define', description='Gets the definition of a word (placeholder).')
    async def define(self, interaction: discord.Interaction, word: str):
        """Gets the definition of a word (placeholder)."""
        await interaction.response.send_message(f"Defining '{word}'... (This command is a placeholder)")
        await interaction.response.send_message("You would typically integrate with an API like Merriam-Webster or Oxford Dictionaries here.")

    # Command: Translate (placeholder for translation API)
    @app_commands.command(name='translate', description='Translates text (placeholder).')
    async def translate(self, interaction: discord.Interaction, lang_code: str, text: str):
        """Translates text (placeholder)."""
        await interaction.response.send_message(f"Translating '{text}' to {lang_code}... (This command is a placeholder)")
        await interaction.response.send_message("You would typically integrate with an API like Google Translate or DeepL here.")

    # Command: QR Code (placeholder for QR code generation)
    @app_commands.command(name='qrcode', description='Generates a QR code for given text.')
    async def qrcode(self, interaction: discord.Interaction, text: str):
        """Generates a QR code for the given text."""
        # This would typically involve a QR code API or a library like `qrcode`
        # For example: https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=Hello%20World
        qr_url = f"https://api.qrserver.com/v1/create-qr-code/?size=150x150&data={text.replace(' ', '%20')}"
        embed = discord.Embed(
            title="QR Code Generated",
            description=f"For: `{text}`",
            color=discord.Color.blue()
        )
        embed.set_image(url=qr_url)
        await interaction.response.send_message(embed=embed)

    # Command: Countdown
    @app_commands.command(name='countdown', description='Starts a countdown.')
    @app_commands.checks.check(lambda i: i.client._check_user_or_role_allowed(i.user, i.client.allowed_user_ids, i.client.allowed_role_ids))  # Corrected check
    async def countdown(self, interaction: discord.Interaction, seconds: int):
        """Starts a countdown."""
        if seconds <= 0:
            await interaction.response.send_message("Please provide a positive number of seconds.")
            return
        message = await interaction.response.send_message(f"Countdown: {seconds}")  # Send initial message
        message = await message.original_response()  # Get the actual message object

        for i in range(seconds - 1, 0, -1):
            await asyncio.sleep(1)
            await message.edit(content=f"Countdown: {i}")
        await asyncio.sleep(1)
        await message.edit(content="Countdown finished! 🚀")

    # Command: Timer
    @app_commands.command(name='timer', description='Sets a timer.')
    @app_commands.checks.check(lambda i: i.client._check_user_or_role_allowed(i.user, i.client.allowed_user_ids, i.client.allowed_role_ids))  # Corrected check
    async def timer(self, interaction: discord.Interaction, minutes: int, message: str = "Timer finished!"):
        """Sets a timer for the specified minutes."""
        if minutes <= 0:
            await interaction.response.send_message("Please provide a positive number of minutes.")
            return
        await interaction.response.send_message(f"Timer set for {minutes} minutes. I'll remind you about: `{message}`")
        await asyncio.sleep(minutes * 60)
        await interaction.channel.send(f"{interaction.user.mention}, your timer for `{minutes}` minutes is up! Reminder: `{message}`")


async def setup(bot):
    """
    Adds the Misc cog to the bot.
    """
    await bot.add_cog(Misc(bot))