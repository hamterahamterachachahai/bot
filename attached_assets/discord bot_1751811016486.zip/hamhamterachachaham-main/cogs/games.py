# cogs/games.py
import discord
from discord.ext import commands
from discord import app_commands  # Import app_commands
import random
import asyncio

# Declare global variables for the checks, which will be assigned in cog_load
# This is necessary because these functions are defined in bot.py's global scope.
_check_allowed_users = None
_check_user_or_role_allowed = None # Assuming you want to use the combined check from bot.py

class Games(commands.Cog):
    """
    Simple game commands.
    """
    def __init__(self, bot):
        self.bot = bot
        self.rps_games = {} # To store ongoing Rock-Paper-Scissors games

    async def cog_load(self):
        """
        Assigns the global check functions from the bot instance to local variables
        when the cog is loaded. This makes them accessible within the cog's commands.
        """
        global _check_allowed_users
        global _check_user_or_role_allowed
        # Access the functions assumed to be attached to the bot instance from bot.py
        _check_allowed_users = self.bot.check_allowed_users
        _check_user_or_role_allowed = self.bot.check_user_or_role_allowed


    # Command: Rock Paper Scissors
    @app_commands.command(name='rps', description='Play Rock, Paper, Scissors against the bot.')
    async def rps(self, interaction: discord.Interaction, player_choice: str):
        """Plays Rock, Paper, Scissors against the bot."""
        choices = ['rock', 'paper', 'scissors']
        player_choice = player_choice.lower()

        if player_choice not in choices:
            await interaction.response.send_message("Please choose rock, paper, or scissors.")
            return

        bot_choice = random.choice(choices)
        result = ""

        if player_choice == bot_choice:
            result = "It's a tie!"
        elif (player_choice == 'rock' and bot_choice == 'scissors') or \
             (player_choice == 'paper' and bot_choice == 'rock') or \
             (player_choice == 'scissors' and bot_choice == 'paper'):
            result = "You win!"
        else:
            result = "I win!"

        await interaction.response.send_message(f"You chose: {player_choice.capitalize()}\nI chose: {bot_choice.capitalize()}\n{result}")

    # Command: Guess the Number
    @app_commands.command(name='guessthenumber', description='Start a guess the number game.')
    # Using the combined check for user OR role
    @app_commands.checks.check(lambda i: _check_user_or_role_allowed(i))
    async def guessthenumber(self, interaction: discord.Interaction, max_number: int = 100):
        """Starts a guess the number game."""
        if max_number < 10:
            await interaction.response.send_message("Please choose a max number of at least 10.")
            return

        secret_number = random.randint(1, max_number)
        await interaction.response.send_message(f"I'm thinking of a number between 1 and {max_number}. Guess it!")

        def check(m):
            return m.author == interaction.user and m.channel == interaction.channel and m.content.isdigit()

        try:
            for _ in range(5): # 5 guesses
                msg = await self.bot.wait_for('message', check=check, timeout=30.0)
                guess = int(msg.content)

                if guess == secret_number:
                    await interaction.response.send_message(f"Congratulations, {interaction.user.mention}! You guessed it! The number was {secret_number}.")
                    return
                elif guess < secret_number:
                    await interaction.response.send_message("Too low! Try again.")
                else:
                    await interaction.response.send_message("Too high! Try again.")
            await interaction.response.send_message(f"You ran out of guesses! The number was {secret_number}.")
        except asyncio.TimeoutError:
            await interaction.response.send_message(f"Time's up! The number was {secret_number}.")

    # Command: Coinflip (already in Fun, but can be here too for games category)
    @app_commands.command(name='coinflipgame', description='Flips a coin for a game.')
    async def coinflip_game(self, interaction: discord.Interaction):
        """Flips a coin and tells you heads or tails."""
        result = random.choice(['Heads', 'Tails'])
        await interaction.response.send_message(f'The coin landed on: {result}!')

    # Command: Dice Roll (already in Fun, but can be here too for games category)
    @app_commands.command(name='dicerollgame', description='Rolls a dice for a game.')
    async def diceroll_game(self, interaction: discord.Interaction, sides: int = 6):
        """Rolls a dice with a specified number of sides."""
        if sides < 2:
            await interaction.response.send_message("A dice must have at least 2 sides!")
            return
        result = random.randint(1, sides)
        await interaction.response.send_message(f'You rolled a {result} (out of {sides}).')

    # Command: Trivia (placeholder, requires question/answer data)
    @app_commands.command(name='trivia', description='Starts a trivia game.')
    # Using the combined check for user OR role
    @app_commands.checks.check(lambda i: _check_user_or_role_allowed(i))
    async def trivia(self, interaction: discord.Interaction):
        """Starts a trivia game (placeholder)."""
        await interaction.response.send_message("Starting a trivia game! (Not yet implemented - needs questions/answers)")
        # Example:
        # questions = [{"q": "What is the capital of France?", "a": "Paris"}]
        # question = random.choice(questions)
        # await ctx.send(f"Question: {question['q']}")
        # def check(m): return m.author == ctx.author and m.channel == ctx.channel
        # try:
        #     msg = await self.bot.wait_for('message', check=check, timeout=15.0)
        #     if msg.content.lower() == question['a'].lower():
        #         await ctx.send("Correct!")
        #     else:
        #         await ctx.send(f"Wrong! The answer was {question['a']}.")
        # except asyncio.TimeoutError:
        #     await ctx.send(f"Time's up! The answer was {question['a']}.")

    # Command: Tic-Tac-Toe (placeholder, complex to implement fully without reactions/buttons)
    @app_commands.command(name='tictactoe', description='Starts a Tic-Tac-Toe game against another player.')
    # Using the combined check for user OR role
    @app_commands.checks.check(lambda i: _check_user_or_role_allowed(i))
    async def tictactoe(self, interaction: discord.Interaction, player2: discord.Member):
        """Starts a Tic-Tac-Toe game (placeholder)."""
        await interaction.response.send_message(f"Starting Tic-Tac-Toe between {interaction.user.mention} and {player2.mention}! (Complex, not fully implemented here)")
        await interaction.response.send_message("This would require a game board, turn management, and input handling (e.g., reactions or buttons).")

async def setup(bot):
    """
    Adds the Games cog to the bot.
    """
    await bot.add_cog(Games(bot))