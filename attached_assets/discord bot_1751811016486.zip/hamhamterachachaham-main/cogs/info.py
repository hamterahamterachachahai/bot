# cogs/info.py
import discord
from discord.ext import commands
from discord import app_commands  # Import app_commands
import platform
import psutil # You might need to 'pip install psutil' for system info
import datetime

class Info(commands.Cog):
    """
    Commands providing information about the bot and Discord.
    """
    def __init__(self, bot):
        self.bot = bot
        self.bot.uptime = datetime.datetime.utcnow() # Initialize uptime here

    # Command: Bot Info
    @app_commands.command(name='botinfo', description='Displays information about the bot.')
    async def botinfo(self, interaction: discord.Interaction):
        """Displays detailed information about the bot."""
        uptime_seconds = (datetime.datetime.utcnow() - self.bot.uptime).total_seconds()
        hours, remainder = divmod(int(uptime_seconds), 3600)
        minutes, seconds = divmod(remainder, 60)
        uptime_string = f"{hours}h {minutes}m {seconds}s"

        # Get CPU and RAM usage (requires psutil)
        cpu_usage = psutil.cpu_percent()
        ram_usage = psutil.virtual_memory().percent

        embed = discord.Embed(
            title=f"Bot Info: {self.bot.user.name}",
            description="A versatile Discord bot!",
            color=discord.Color.blue(),
            timestamp=datetime.datetime.utcnow()
        )
        embed.set_thumbnail(url=self.bot.user.avatar.url if self.bot.user.avatar else self.bot.user.default_avatar.url)
        embed.add_field(name="Developer", value=f"<@{self.bot.owner_id}>" if self.bot.owner_id else "Not set", inline=True)
        embed.add_field(name="Library", value=f"discord.py v{discord.__version__}", inline=True)
        embed.add_field(name="Python Version", value=platform.python_version(), inline=True)
        embed.add_field(name="Servers", value=len(self.bot.guilds), inline=True)
        embed.add_field(name="Users", value=len(self.bot.users), inline=True)
        embed.add_field(name="Commands", value=len(self.bot.commands), inline=True)
        embed.add_field(name="Latency", value=f"{round(self.bot.latency * 1000)}ms", inline=True)
        embed.add_field(name="Uptime", value=uptime_string, inline=True)
        embed.add_field(name="CPU Usage", value=f"{cpu_usage}%", inline=True)
        embed.add_field(name="RAM Usage", value=f"{ram_usage}%", inline=True)
        embed.set_footer(text=f"Bot ID: {self.bot.user.id}")

        await interaction.response.send_message(embed=embed)

    # Command: Help (Custom Help Command)
    # This is more complex to convert directly to slash commands due to its dynamic nature.
    # Slash commands work best when you define the options explicitly.
    # A simpler slash command help might just list all commands.  A more advanced one
    # would require UI elements like dropdowns to select a command.
    @app_commands.command(name='help', description='Displays a list of bot commands.')
    async def help_command(self, interaction: discord.Interaction):
        """Displays help for all commands."""
        embed = discord.Embed(
            title="Bot Commands",
            description="Here's a list of available commands:",
            color=discord.Color.blue()
        )

        for cmd in self.bot.commands:
            if not cmd.hidden:  # Don't show hidden commands
                embed.add_field(name=f"/{cmd.name}", value=cmd.help or "No description", inline=False)

        await interaction.response.send_message(embed=embed)

    # Command: Latency
    @app_commands.command(name='latency', description='Shows the bot\'s current latency to Discord.')
    async def latency(self, interaction: discord.Interaction):
        """Shows the bot's current latency to Discord."""
        await interaction.response.send_message(f'Pong! {round(self.bot.latency * 1000)}ms')

    # Command: Uptime
    @app_commands.command(name='uptime', description='Shows how long the bot has been online.')
    async def uptime(self, interaction: discord.Interaction):
        """Shows how long the bot has been online."""
        uptime_seconds = (datetime.datetime.utcnow() - self.bot.uptime).total_seconds()
        hours, remainder = divmod(int(uptime_seconds), 3600)
        minutes, seconds = divmod(remainder, 60)
        await interaction.response.send_message(f'I have been online for: {hours}h {minutes}m {seconds}s')

    # Command: Invite
    @app_commands.command(name='invite', description='Provides the bot\'s invite link.')
    async def invite(self, interaction: discord.Interaction):
        """Provides the bot's invite link."""
        # Replace YOUR_CLIENT_ID with your bot's actual client ID from the Discord Developer Portal
        # You can get your bot's client ID from bot.user.id after it's logged in.
        # It's good practice to generate the invite link with necessary permissions.
        # Example permissions: Read Messages, Send Messages, Manage Messages, Kick Members, Ban Members
        permissions = discord.Permissions(
            read_messages=True,
            send_messages=True,
            manage_messages=True,
            kick_members=True,
            ban_members=True,
            manage_roles=True,
            change_nickname=True
        )
        invite_link = discord.utils.oauth_url(self.bot.user.id, permissions=permissions)
        await interaction.response.send_message(f"Invite me to your server: {invite_link}")

    # Command: Source (link to GitHub repo if applicable)
    @app_commands.command(name='source', description='Provides a link to the bot\'s source code.')
    async def source(self, interaction: discord.Interaction):
        """Provides a link to the bot's source code (placeholder)."""
        await interaction.response.send_message("My source code is not publicly available yet, but I'm built with love using `discord.py`!")
        # In a real scenario, you'd link to your GitHub repo:
        # await interaction.response.send_message("You can find my source code here: <YOUR_GITHUB_REPO_LINK>")


async def setup(bot):
    """
    Adds the Info cog to the bot.
    Initializes bot.uptime when the cog is loaded.
    """
    await bot.add_cog(Info(bot))