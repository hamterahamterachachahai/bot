# cogs/fun.py
import discord
from discord.ext import commands
from discord import app_commands  # Import app_commands
import random
import aiohttp # For fetching data from APIs

class Fun(commands.Cog):
    """
    Fun and entertainment commands.
    """
    def __init__(self, bot):
        self.bot = bot

    # Command: Dice Roll
    @app_commands.command(name='roll', description='Rolls a dice.')
    async def roll(self, interaction: discord.Interaction, sides: int = 6):
        """Rolls a dice with a specified number of sides."""
        if sides < 2:
            await interaction.response.send_message("A dice must have at least 2 sides!")
            return
        result = random.randint(1, sides)
        await interaction.response.send_message(f'You rolled a {result} (out of {sides}).')

    # Command: 8ball
    @app_commands.command(name='eightball', description='Asks the magic 8-ball a question.')
    async def eightball(self, interaction: discord.Interaction, question: str):
        """Asks the magic 8-ball a question and gets a random answer."""
        responses = [
            "It is certain.",
            "It is decidedly so.",
            "Without a doubt.",
            "Yes - definitely.",
            "You may rely on it.",
            "As I see it, yes.",
            "Most likely.",
            "Outlook good.",
            "Yes.",
            "Signs point to yes.",
            "Reply hazy, try again.",
            "Ask again later.",
            "Better not tell you now.",
            "Cannot predict now.",
            "Concentrate and ask again.",
            "Don't count on it.",
            "My reply is no.",
            "My sources say no.",
            "Outlook not so good.",
            "Very doubtful."
        ]
        await interaction.response.send_message(f'Question: {question}\nAnswer: {random.choice(responses)}')

    # Command: Coin Flip
    @app_commands.command(name='coinflip', description='Flips a coin.')
    async def coinflip(self, interaction: discord.Interaction):
        """Flips a coin and tells you heads or tails."""
        result = random.choice(['Heads', 'Tails'])
        await interaction.response.send_message(f'The coin landed on: {result}!')

    # Command: Choose
    @app_commands.command(name='choose', description='Chooses randomly from a list of options.')
    async def choose(self, interaction: discord.Interaction, options: str):
        """Chooses randomly from a comma-separated list of options."""
        choices = [opt.strip() for opt in options.split(',')]
        if len(choices) < 2:
            await interaction.response.send_message("Please provide at least two options separated by commas.")
            return
        await interaction.response.send_message(f'I choose: {random.choice(choices)}')

    # Command: Joke (uses an external API)
    @app_commands.command(name='joke', description='Tells a random joke.')
    async def joke(self, interaction: discord.Interaction):
        """Fetches and tells a random joke."""
        await interaction.response.defer()
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get('https://official-joke-api.appspot.com/random_joke') as response:
                    if response.status == 200:
                        joke_data = await response.json()
                        await interaction.followup.send(f"{joke_data['setup']}\n||{joke_data['punchline']}||")
                    else:
                        await interaction.followup.send("Could not fetch a joke at this time. Try again later.")
        except aiohttp.ClientError:
            await interaction.followup.send("Failed to connect to the joke API. Please check your internet connection or try again later.")
        except Exception as e:
            await interaction.followup.send(f"An unexpected error occurred while fetching a joke: {e}")

    # Command: Cat Fact (uses an external API)
    @app_commands.command(name='catfact', description='Gives a random cat fact.')
    async def catfact(self, interaction: discord.Interaction):
        """Fetches and sends a random cat fact."""
        await interaction.response.defer()
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get('https://catfact.ninja/fact') as response:
                    if response.status == 200:
                        fact_data = await response.json()
                        await interaction.followup.send(f"🐱 Cat Fact: {fact_data['fact']}")
                    else:
                        await interaction.followup.send("Could not fetch a cat fact at this time. Try again later.")
        except aiohttp.ClientError:
            await interaction.followup.send("Failed to connect to the cat fact API. Please check your internet connection or try again later.")
        except Exception as e:
            await interaction.followup.send(f"An unexpected error occurred while fetching a cat fact: {e}")

    # Command: Doggo (placeholder, would typically fetch dog images)
    @app_commands.command(name='doggo', description='Sends a random dog picture.')
    async def doggo(self, interaction: discord.Interaction):
        """Sends a random dog picture (placeholder)."""
        # In a real bot, you'd integrate with a dog API like dog.ceo/api/breeds/image/random
        await interaction.response.send_message("Woof! (This command would show a dog pic if integrated with an API!)")

    # Command: Pun (placeholder)
    @app_commands.command(name='pun', description='Tells a terrible pun.')
    async def pun(self, interaction: discord.Interaction):
        """Tells a random pun (placeholder)."""
        puns = [
            "Why don't scientists trust atoms? Because they make up everything!",
            "I'm reading a book about anti-gravity. It's impossible to put down!",
            "Did you hear about the restaurant on the moon? Great food, no atmosphere.",
            "What do you call a fake noodle? An impasta!",
            "I used to be a baker, but I couldn't make enough dough."
        ]
        await interaction.response.send_message(random.choice(puns))

    # Command: Rate
    @app_commands.command(name='rate', description='Rates something out of 10.')
    async def rate(self, interaction: discord.Interaction, thing: str):
        """Rates a given thing out of 10."""
        rating = random.randint(1, 10)
        await interaction.response.send_message(f'I rate "{thing}" a **{rating}/10**!')

    # Command: Ship (placeholder for pairing users)
    @app_commands.command(name='ship', description='Ships two users together.')
    async def ship(self, interaction: discord.Interaction, member1: discord.Member, member2: discord.Member):
        """Ships two users together with a compatibility percentage."""
        compatibility = random.randint(0, 100)
        await interaction.response.send_message(f'💖 {member1.display_name} and {member2.display_name} have {compatibility}% compatibility! 💖')


async def setup(bot):
    """
    Adds the Fun cog to the bot.
    """
    await bot.add_cog(Fun(bot))