# cogs/moderation.py
import discord
from discord.ext import commands
from discord import app_commands  # Import app_commands
import asyncio

class Moderation(commands.Cog):
    """
    Commands for server moderation.
    Requires appropriate permissions for the bot and the user.
    """
    def __init__(self, bot):
        self.bot = bot

    # Command: Kick
    @app_commands.command(name='kick', description='Kicks a member from the server.')
    @app_commands.checks.has_permissions(kick_members=True)
    @app_commands.checks.bot_has_permissions(kick_members=True)
    async def kick(self, interaction: discord.Interaction, member: discord.Member, reason: str = "No reason provided."):
        """Kicks the specified member from the server."""
        try:
            await member.kick(reason=reason)
            await interaction.response.send_message(f'{member.display_name} has been kicked for: {reason}')
        except discord.Forbidden:
            await interaction.response.send_message("I don't have permission to kick that member. Make sure my role is above theirs.", ephemeral=True)
        except Exception as e:
            await interaction.response.send_message(f"An error occurred while trying to kick: {e}", ephemeral=True)

    # Command: Ban
    @app_commands.command(name='ban', description='Bans a member from the server.')
    @app_commands.checks.has_permissions(ban_members=True)
    @app_commands.checks.bot_has_permissions(ban_members=True)
    async def ban(self, interaction: discord.Interaction, member: discord.Member, reason: str = "No reason provided."):
        """Bans the specified member from the server."""
        try:
            await member.ban(reason=reason)
            await interaction.response.send_message(f'{member.display_name} has been banned for: {reason}')
        except discord.Forbidden:
            await interaction.response.send_message("I don't have permission to ban that member. Make sure my role is above theirs.", ephemeral=True)
        except Exception as e:
            await interaction.response.send_message(f"An error occurred while trying to ban: {e}", ephemeral=True)

    # Command: Unban
    @app_commands.command(name='unban', description='Unbans a user by their ID or username#discriminator.')
    @app_commands.checks.has_permissions(ban_members=True)
    @app_commands.checks.bot_has_permissions(ban_members=True)
    async def unban(self, interaction: discord.Interaction, user_id_or_name: str):
        """Unbans a user from the server."""
        banned_users = await interaction.guild.bans()
        found_user = None

        for ban_entry in banned_users:
            user = ban_entry.user
            if str(user.id) == user_id_or_name or str(user) == user_id_or_name:
                found_user = user
                break

        if found_user:
            try:
                await interaction.guild.unban(found_user)
                await interaction.response.send_message(f'{found_user.name} has been unbanned.')
            except discord.Forbidden:
                await interaction.response.send_message("I don't have permission to unban that user.", ephemeral=True)
            except Exception as e:
                await interaction.response.send_message(f"An error occurred while trying to unban: {e}", ephemeral=True)
        else:
            await interaction.response.send_message(f"Could not find a banned user with ID or name: `{user_id_or_name}`")

    # Command: Mute (using roles)
    @app_commands.command(name='mute', description='Mutes a member by assigning a "Muted" role.')
    @app_commands.checks.has_permissions(manage_roles=True)
    @app_commands.checks.bot_has_permissions(manage_roles=True)
    async def mute(self, interaction: discord.Interaction, member: discord.Member, duration_minutes: int = 0, reason: str = "No reason provided."):
        """Mutes the specified member."""
        muted_role = discord.utils.get(interaction.guild.roles, name="Muted")

        if not muted_role:
            await interaction.response.send_message("Error: 'Muted' role not found. Please create a role named 'Muted'.", ephemeral=True)
            return

        if muted_role in member.roles:
            await interaction.response.send_message(f"{member.display_name} is already muted.", ephemeral=True)
            return

        try:
            await member.add_roles(muted_role, reason=reason)
            await interaction.response.send_message(f'{member.display_name} has been muted for: {reason}')

            if duration_minutes > 0:
                await interaction.channel.send(f"Muting {member.display_name} for {duration_minutes} minutes.")
                await asyncio.sleep(duration_minutes * 60)
                await member.remove_roles(muted_role, reason="Mute duration ended.")
                await interaction.channel.send(f"{member.display_name} has been unmuted automatically.")

        except discord.Forbidden:
            await interaction.response.send_message("I don't have permission to manage roles.", ephemeral=True)
        except Exception as e:
            await interaction.response.send_message(f"An error occurred while trying to mute: {e}", ephemeral=True)

    # Command: Unmute
    @app_commands.command(name='unmute', description='Unmutes a member by removing the "Muted" role.')
    @app_commands.checks.has_permissions(manage_roles=True)
    @app_commands.checks.bot_has_permissions(manage_roles=True)
    async def unmute(self, interaction: discord.Interaction, member: discord.Member):
        """Unmutes the specified member."""
        muted_role = discord.utils.get(interaction.guild.roles, name="Muted")

        if not muted_role or muted_role not in member.roles:
            await interaction.response.send_message(f"{member.display_name} is not currently muted or the 'Muted' role doesn't exist.", ephemeral=True)
            return

        try:
            await member.remove_roles(muted_role, reason="Unmuted by moderator.")
            await interaction.response.send_message(f'{member.display_name} has been unmuted.')
        except discord.Forbidden:
            await interaction.response.send_message("I don't have permission to manage roles.", ephemeral=True)
        except Exception as e:
            await interaction.response.send_message(f"An error occurred while trying to unmute: {e}", ephemeral=True)

    # Command: Clear/Purge messages
    @app_commands.command(name='clear', description='Deletes a specified number of messages from the channel.')
    @app_commands.checks.has_permissions(manage_messages=True)
    @app_commands.checks.bot_has_permissions(manage_messages=True)
    async def clear(self, interaction: discord.Interaction, amount: int):
        """Deletes a specified number of messages."""
        if amount <= 0:
            await interaction.response.send_message("Please specify a positive number of messages to clear.", ephemeral=True)
            return
        if amount > 100:
            await interaction.response.send_message("I can only clear up to 100 messages at a time.", ephemeral=True)
            amount = 100 # Discord API limit for bulk delete

        try:
            await interaction.response.defer(ephemeral=True) # Acknowledge the command
            deleted = await interaction.channel.purge(limit=amount + 1) # +1 to account for the command message
            await interaction.followup.send(f'Successfully deleted {len(deleted) - 1} messages.', ephemeral=True, delete_after=5)
        except discord.Forbidden:
            await interaction.followup.send("I don't have permission to manage messages in this channel.", ephemeral=True)
        except discord.HTTPException as e:
            await interaction.followup.send(f"Failed to clear messages: {e}. Messages older than 14 days cannot be bulk deleted.", ephemeral=True)
        except Exception as e:
            await interaction.followup.send(f"An error occurred while trying to clear messages: {e}", ephemeral=True)

    # Command: Warn
    @app_commands.command(name='warn', description='Warns a member.')
    @app_commands.checks.has_permissions(kick_members=True) # Typically, warn requires kick/ban perms
    async def warn(self, interaction: discord.Interaction, member: discord.Member, reason: str = "No reason provided."):
        """Warns the specified member and sends them a DM."""
        try:
            await member.send(f"You have been warned in {interaction.guild.name} for: {reason}")
            await interaction.response.send_message(f'{member.display_name} has been warned for: {reason}')
        except discord.Forbidden:
            await interaction.response.send_message(f"Could not DM {member.display_name}. Warning issued, but DM failed.", ephemeral=True)
        except Exception as e:
            await interaction.response.send_message(f"An error occurred while trying to warn: {e}", ephemeral=True)

    # Command: Set Nickname
    @app_commands.command(name='setnick', description='Changes the nickname of a member.')
    @app_commands.checks.has_permissions(manage_nicknames=True)
    @app_commands.checks.bot_has_permissions(manage_nicknames=True)
    async def setnick(self, interaction: discord.Interaction, member: discord.Member, nickname: str = None):
        """Changes the nickname of the specified member."""
        try:
            old_nick = member.nick if member.nick else member.name
            await member.edit(nick=nickname)
            if nickname:
                await interaction.response.send_message(f'Changed {old_nick}\'s nickname to {nickname}.')
            else:
                await interaction.response.send_message(f'Reset {old_nick}\'s nickname.')
        except discord.Forbidden:
            await interaction.response.send_message("I don't have permission to change that member's nickname.", ephemeral=True)
        except Exception as e:
            await interaction.response.send_message(f"An error occurred while trying to set nickname: {e}", ephemeral=True)

    # Command: Slowmode
    @app_commands.command(name='slowmode', description='Sets the slowmode duration for the current channel.')
    @app_commands.checks.has_permissions(manage_channels=True)
    @app_commands.checks.bot_has_permissions(manage_channels=True)
    async def slowmode(self, interaction: discord.Interaction, seconds: int):
        """Sets the slowmode duration for the current channel."""
        if seconds < 0 or seconds > 21600: # Max 6 hours (21600 seconds)
            await interaction.response.send_message("Slowmode duration must be between 0 and 21600 seconds.", ephemeral=True)
            return
        try:
            await interaction.channel.edit(slowmode_delay=seconds)
            if seconds == 0:
                await interaction.response.send_message("Slowmode has been disabled for this channel.")
            else:
                await interaction.response.send_message(f"Slowmode set to {seconds} seconds for this channel.")
        except discord.Forbidden:
            await interaction.response.send_message("I don't have permission to manage channels.", ephemeral=True)
        except Exception as e:
            await interaction.response.send_message(f"An error occurred while trying to set slowmode: {e}", ephemeral=True)


async def setup(bot):
    """
    Adds the Moderation cog to the bot.
    This function is called when the cog is loaded.
    """
    await bot.add_cog(Moderation(bot))