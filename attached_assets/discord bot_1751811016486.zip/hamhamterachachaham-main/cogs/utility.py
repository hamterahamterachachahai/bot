# cogs/utility.py
import discord
from discord.ext import commands
import datetime
from discord import app_commands  # Import app_commands
import asyncio

# Declare global variables for the checks, which will be assigned in cog_load
# This is necessary because these functions are defined in bot.py's global scope.
_check_allowed_users = None
_check_user_or_role_allowed = None # Assuming you want to use the combined check from bot.py

class Utility(commands.Cog):
    """
    General utility commands.
    """
    def __init__(self, bot):
        self.bot = bot

    async def cog_load(self):
        """
        Assigns the global check functions from the bot instance to local variables
        when the cog is loaded. This makes them accessible within the cog's commands.
        """
        global _check_allowed_users
        global _check_user_or_role_allowed
        # Access the functions assumed to be attached to the bot instance from bot.py
        _check_allowed_users = self.bot.check_allowed_users
        _check_user_or_role_allowed = self.bot.check_user_or_role_allowed

    # Command: User Info
    @app_commands.command(name='userinfo', description='Displays information about a user.')
    # Using the combined check for user OR role
    @app_commands.checks.check(lambda i: _check_user_or_role_allowed(i.user, i.client.allowed_user_ids, i.client.allowed_role_ids))
    @app_commands.describe(member='The user to get info about (defaults to yourself)')
    async def userinfo(self, interaction: discord.Interaction, member: discord.Member = None):
        """Displays detailed information about a user."""
        member = member or interaction.user # Defaults to the command invoker

        embed = discord.Embed(
            title=f"User Info: {member.display_name}",
            color=member.color if member.color != discord.Color.default() else discord.Color.blue(),
            timestamp=datetime.datetime.utcnow()
        )
        embed.set_thumbnail(url=member.avatar.url if member.avatar else member.default_avatar.url)
        embed.add_field(name="ID", value=member.id, inline=True)
        embed.add_field(name="Discriminator", value=member.discriminator, inline=True)
        embed.add_field(name="Bot?", value="Yes" if member.bot else "No", inline=True)
        embed.add_field(name="Created On", value=member.created_at.strftime("%Y-%m-%d %H:%M:%S UTC"), inline=False)
        embed.add_field(name="Joined Server On", value=member.joined_at.strftime("%Y-%m-%d %H:%M:%S UTC"), inline=False)

        roles = [role.mention for role in member.roles if role.name != "@everyone"]
        if roles:
            embed.add_field(name=f"Roles ({len(roles)})", value=" ".join(roles), inline=False)
        else:
            embed.add_field(name="Roles", value="No roles other than @everyone.", inline=False)

        await interaction.response.send_message(embed=embed)

    # Command: Server Info
    @app_commands.command(name='serverinfo', description='Displays information about the current server.')
    # Using the combined check for user OR role
    @app_commands.checks.check(lambda i: _check_user_or_role_allowed(i.user, i.client.allowed_user_ids, i.client.allowed_role_ids))
    async def serverinfo(self, interaction: discord.Interaction):
        """Displays detailed information about the current server."""
        guild = interaction.guild

        embed = discord.Embed(
            title=f"Server Info: {guild.name}",
            color=discord.Color.green(),
            timestamp=datetime.datetime.utcnow()
        )
        if guild.icon:
            embed.set_thumbnail(url=guild.icon.url)
        if guild.owner:
            embed.add_field(name="Owner", value=guild.owner.mention, inline=True)
        embed.add_field(name="ID", value=guild.id, inline=True)
        embed.add_field(name="Members", value=guild.member_count, inline=True)
        embed.add_field(name="Channels", value=f"{len(guild.text_channels)} Text, {len(guild.voice_channels)} Voice", inline=True)
        embed.add_field(name="Roles", value=len(guild.roles), inline=True)
        embed.add_field(name="Created On", value=guild.created_at.strftime("%Y-%m-%d %H:%M:%S UTC"), inline=False)
        embed.add_field(name="Region", value=str(guild.preferred_locale).capitalize(), inline=True)
        embed.add_field(name="Boost Level", value=guild.premium_tier, inline=True)
        embed.add_field(name="Boosts", value=guild.premium_subscription_count, inline=True)

        await interaction.response.send_message(embed=embed)

    # Command: Avatar
    @app_commands.command(name='avatar', description='Displays a user\'s avatar.')
    # Using the combined check for user OR role
    @app_commands.checks.check(lambda i: _check_user_or_role_allowed(i.user, i.client.allowed_user_ids, i.client.allowed_role_ids))
    @app_commands.describe(member='The user whose avatar to show (defaults to yourself)')
    async def avatar(self, interaction: discord.Interaction, member: discord.Member = None):
        """Displays the avatar of the specified user."""
        member = member or interaction.user
        embed = discord.Embed(
            title=f"{member.display_name}'s Avatar",
            color=discord.Color.purple()
        )
        embed.set_image(url=member.avatar.url if member.avatar else member.default_avatar.url)
        await interaction.response.send_message(embed=embed)

    # Command: Channel Info
    @app_commands.command(name='channelinfo', description='Displays information about a channel.')
    # Using the combined check for user OR role
    @app_commands.checks.check(lambda i: _check_user_or_role_allowed(i.user, i.client.allowed_user_ids, i.client.allowed_role_ids))
    @app_commands.describe(channel='The channel to get info about (defaults to current channel)')
    async def channelinfo(self, interaction: discord.Interaction, channel: discord.TextChannel = None):
        """Displays information about a text channel."""
        channel = channel or interaction.channel
        embed = discord.Embed(
            title=f"Channel Info: #{channel.name}",
            color=discord.Color.orange(),
            timestamp=datetime.datetime.utcnow()
        )
        embed.add_field(name="ID", value=channel.id, inline=True)
        embed.add_field(name="Type", value=str(channel.type).capitalize(), inline=True)
        embed.add_field(name="Category", value=channel.category.name if channel.category else "None", inline=True)
        embed.add_field(name="Created On", value=channel.created_at.strftime("%Y-%m-%d %H:%M:%S UTC"), inline=False)
        embed.add_field(name="Slowmode", value=f"{channel.slowmode_delay} seconds", inline=True)
        embed.add_field(name="NSFW", value="Yes" if channel.is_nsfw() else "No", inline=True)
        embed.add_field(name="Topic", value=channel.topic if channel.topic else "No topic set.", inline=False)
        await interaction.response.send_message(embed=embed)

    # Command: Role Info
    @app_commands.command(name='roleinfo', description='Displays information about a role.')
    # Using the combined check for user OR role
    @app_commands.checks.check(lambda i: _check_user_or_role_allowed(i.user, i.client.allowed_user_ids, i.client.allowed_role_ids))
    @app_commands.describe(role='The role to get info about')
    async def roleinfo(self, interaction: discord.Interaction, role: discord.Role):
        """Displays information about a role."""
        embed = discord.Embed(
            title=f"Role Info: {role.name}",
            color=role.color if role.color != discord.Color.default() else discord.Color.light_grey(),
            timestamp=datetime.datetime.utcnow()
        )
        embed.add_field(name="ID", value=role.id, inline=True)
        embed.add_field(name="Members", value=len(role.members), inline=True)
        embed.add_field(name="Hoisted", value="Yes" if role.hoist else "No", inline=True)
        embed.add_field(name="Mentionable", value="Yes" if role.mentionable else "No", inline=True)
        embed.add_field(name="Managed by Integration", value="Yes" if role.managed else "No", inline=True)
        embed.add_field(name="Created On", value=role.created_at.strftime("%Y-%m-%d %H:%M:%S UTC"), inline=False)
        embed.add_field(name="Color (Hex)", value=str(role.color), inline=True)

        await interaction.response.send_message(embed=embed)

    # Command: Say
    @app_commands.command(name='say', description='Makes the bot say something.')
    # Using the combined check for user OR role
    @app_commands.checks.check(lambda i: _check_user_or_role_allowed(i.user, i.client.allowed_user_ids, i.client.allowed_role_ids))
    @app_commands.describe(text='The text to say')
    @app_commands.checks.has_permissions(manage_messages=True)
    async def say(self, interaction: discord.Interaction, text: str):
        """Makes the bot repeat the given text."""
        await interaction.response.send_message(text)
        await interaction.delete_original_response() # Delete the command message

    # Command: Embed
    @app_commands.command(name='embed', description='Creates a simple embed message.')
    # Using the combined check for user OR role
    @app_commands.checks.check(lambda i: _check_user_or_role_allowed(i.user, i.client.allowed_user_ids, i.client.allowed_role_ids))
    @app_commands.describe(title='The title of the embed', description='The description of the embed', color_hex='Optional hex color code (e.g., #RRGGBB)')
    @app_commands.checks.has_permissions(manage_messages=True)
    async def embed(self, interaction: discord.Interaction, title: str, description: str = None, color_hex: str = None):
        """Creates a simple embed message."""
        color = discord.Color.blue() # Default color

        if color_hex:
            try:
                color = discord.Color(int(color_hex.replace('#', ''), 16))
            except ValueError:
                await interaction.response.send_message("Invalid color hex. Using default blue.", ephemeral=True)
                color = discord.Color.blue()

        embed = discord.Embed(
            title=title,
            description=description,
            color=color
        )
        await interaction.response.send_message(embed=embed)
        await interaction.delete_original_response()

    # Command: Remind Me
    @app_commands.command(name='remindme', description='Sets a reminder.')
    # Using the combined check for user OR role
    @app_commands.checks.check(lambda i: _check_user_or_role_allowed(i.user, i.client.allowed_user_ids, i.client.allowed_role_ids))
    @app_commands.describe(time='The amount of time', unit='The unit of time (seconds, minutes, hours, days)', message='The reminder message')
    async def remindme(self, interaction: discord.Interaction, time: int, unit: str, message: str):
        """Sets a reminder for the user."""
        unit = unit.lower()
        if unit not in ['seconds', 'minutes', 'hours', 'days']:
            await interaction.response.send_message("Invalid time unit. Please use seconds, minutes, hours, or days.", ephemeral=True)
            return

        if time <= 0:
            await interaction.response.send_message("Time must be a positive number.", ephemeral=True)
            return

        if unit == 'seconds':
            delay = time
        elif unit == 'minutes':
            delay = time * 60
        elif unit == 'hours':
            delay = time * 3600
        elif unit == 'days':
            delay = time * 86400

        await interaction.response.send_message(f"Okay, I will remind you in {time} {unit} about: `{message}`")
        await asyncio.sleep(delay)
        try:
            await interaction.user.send(f"Reminder: {message}")
        except discord.Forbidden:
            await interaction.channel.send(f"{interaction.user.mention}, your reminder is ready: `{message}` (Could not DM you).")
        except Exception as e:
            await interaction.channel.send(f"{interaction.user.mention}, your reminder is ready: `{message}` (Error sending DM).")

    # Command: Vote/Poll
    @app_commands.command(name='vote', description='Creates a simple yes/no poll.')
    # No restriction on vote command
    @app_commands.describe(question='The question for the poll')
    async def vote(self, interaction: discord.Interaction, question: str):
        """Creates a simple yes/no poll with reactions."""
        embed = discord.Embed(
            title="New Poll!",
            description=f"**{question}**\n\nReact with ✅ for Yes, ❌ for No.",
            color=discord.Color.blue()
        )
        embed.set_footer(text=f"Poll by {interaction.user.display_name}")
        await interaction.response.send_message(embed=embed)
        message = await interaction.original_response() # Get the sent message object
        await message.add_reaction('✅')
        await message.add_reaction('❌')
        # We don't delete the command message for slash commands by default


async def setup(bot):
    """
    Adds the Utility cog to the bot.
    """
    await bot.add_cog(Utility(bot))