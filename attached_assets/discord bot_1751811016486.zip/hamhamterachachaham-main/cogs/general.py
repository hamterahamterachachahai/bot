import discord
from discord.ext import commands
from discord import app_commands  # Import app_commands


class General(commands.Cog):
    """
    General purpose commands for everyday use.
    """

    def __init__(self, bot):
        self.bot = bot
        self._check_user_or_role_allowed = None

    async def cog_load(self):
        """
        Assigns the global check functions from the bot instance to local variables
        when the cog is loaded. This makes them accessible within the cog's commands.
        """
        self._check_user_or_role_allowed = self.bot.check_user_or_role_allowed

    # Command: Hello
    @app_commands.command(name='hello', description='Greets the user.')
    async def hello(self, interaction: discord.Interaction):
        """Greets the user."""
        await interaction.response.send_message(f'Hello, {interaction.user.mention}!')

    # Command: Echo
    @app_commands.command(name='echo', description='Repeats the given message.')
    async def echo(self, interaction: discord.Interaction, message: str):
        """Repeats the given message."""
        await interaction.response.send_message(message)

    # Command: Announce (for mods/admins to make announcements)
    @app_commands.command(
        name='announce', description='Makes an announcement in the current channel.'
    )
    @app_commands.checks.has_permissions(
        manage_channels=True
    )  # Requires permission to manage channels
    @app_commands.checks.check(lambda i: i.client._check_user_or_role_allowed(i.user, i.client.allowed_user_ids, i.client.allowed_role_ids))
    async def announce(self, interaction: discord.Interaction, message: str):
        """Makes an announcement."""
        embed = discord.Embed(
            title="📢 Announcement",
            description=message,
            color=discord.Color.gold(),
        )
        embed.set_footer(text=f"Announced by {interaction.user.display_name}")
        await interaction.response.send_message(embed=embed)
        # await ctx.message.delete() # Slash commands don't have ctx.message

    # Command: Suggest
    @app_commands.command(
        name='suggest', description='Sends a suggestion to the bot developers.'
    )
    async def suggest(self, interaction: discord.Interaction, suggestion: str):
        """Sends a suggestion."""
        # In a real bot, you'd log this to a specific channel or database
        # For now, it just confirms the suggestion.
        await interaction.response.send_message(
            f"Thank you for your suggestion, {interaction.user.mention}! I've noted: `{suggestion}`"
        )
        # Example of sending to a specific channel (replace CHANNEL_ID)
        # suggestion_channel = self.bot.get_channel(YOUR_SUGGESTION_CHANNEL_ID)
        # if suggestion_channel:
        #     await suggestion_channel.send(f"New suggestion from {ctx.author.mention} in {ctx.guild.name}: {suggestion}")

    # Command: Report (for reporting users/issues)
    @app_commands.command(name='report', description='Reports a user or an issue.')
    @app_commands.checks.check(lambda i: i.client._check_user_or_role_allowed(i.user, i.client.allowed_user_ids, i.client.allowed_role_ids))
    async def report(
        self,
        interaction: discord.Interaction,
        target: discord.Member = None,
        reason: str = "No reason provided.",
    ):
        """Reports a user or an issue."""
        if target:
            report_message = (
                f"Report from {interaction.user.mention} about {target.mention}: {reason}"
            )
        else:
            report_message = f"Issue reported by {interaction.user.mention}: {reason}"

        await interaction.response.send_message(
            "Your report has been submitted. Thank you for helping keep the server safe!"
        )
        # In a real bot, you'd send this to a dedicated moderation log channel
        # For example:
        # mod_log_channel = self.bot.get_channel(YOUR_MOD_LOG_CHANNEL_ID)
        # if mod_log_channel:
        #     await mod_log_channel.send(report_message)

    # Command: Rules
    @app_commands.command(name='rules', description='Displays the server rules.')
    async def rules(self, interaction: discord.Interaction):
        """Displays the server rules."""
        embed = discord.Embed(
            title="Server Rules",
            description=(
                "Here are the basic rules of our server:\n\n"
                "1. Be respectful to everyone.\n"
                "2. No spamming or excessive use of caps.\n"
                "3. No NSFW content outside designated channels.\n"
                "4. Follow Discord's Terms of Service.\n"
                "5. Have fun!"
            ),
            color=discord.Color.red(),
        )
        embed.set_footer(
            text="Please read and follow these rules to ensure a positive environment."
        )
        await interaction.response.send_message(embed=embed)

    # Command: AFK
    @app_commands.command(name='afk', description='Sets your AFK status.')
    async def afk(self, interaction: discord.Interaction, message: str = "I'm AFK."):
        """Sets your AFK status."""
        # This is a basic implementation. A more advanced one would store AFK status in a database
        # and check for it on message send.
        await interaction.response.send_message(
            f"{interaction.user.mention} is now AFK: {message}"
        )
        # You might want to change their nickname here if the bot has permissions
        # try:
        #     await ctx.author.edit(nick=f"[AFK] {ctx.author.display_name}")
        # except discord.Forbidden:
        #     pass # Bot doesn't have permission to change nicknames

    # Command: Invite Link (for the server)
    @app_commands.command(
        name='serverinvite', description='Generates a server invite link.'
    )
    @app_commands.checks.has_permissions(create_instant_invite=True)
    @app_commands.checks.bot_has_permissions(create_instant_invite=True)
    @app_commands.checks.check(lambda i: i.client._check_user_or_role_allowed(i.user, i.client.allowed_user_ids, i.client.allowed_role_ids))
    async def serverinvite(self, interaction: discord.Interaction):
        """Generates a server invite link."""
        try:
            invite = await interaction.channel.create_invite(max_uses=1, unique=True)
            await interaction.response.send_message(
                f"Here's a one-time invite to the server: {invite.url}"
            )
        except discord.Forbidden:
            await interaction.response.send_message(
                "I don't have permission to create invite links."
            )
        except Exception as e:
            await interaction.response.send_message(
                f"An error occurred while creating invite: {e}"
            )


async def setup(bot):
    """
    Adds the General cog to the bot.
    """
    general_cog = General(bot)
    general_cog._check_user_or_role_allowed = bot.check_user_or_role_allowed
    await bot.add_cog(general_cog)